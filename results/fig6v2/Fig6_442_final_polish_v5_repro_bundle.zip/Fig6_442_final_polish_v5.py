#!/usr/bin/env python3
"""Fig.6 v5 — final visual polish of the approved Fig6_442 4+4+2 layout.

Base: Fig6_442_reproducible.py (approved layout). Frozen CSV unchanged.
Polish only: label decluttering, unified palette/typography, unified
secondary-axis scale, zero-marker consistency, IEEE two-column sizing
(7.087 in wide, true \textwidth of IEEEtran conference,compsoc figure*).

Data are recomputed from Fig6_442_frozen_data.csv only; every scientific
count is guarded below and the script refuses to render on mismatch.
Deterministic: SOURCE_DATE_EPOCH pinned so two runs are byte-identical.

Run:  python Fig6_442_final_polish_v5.py   (needs numpy + matplotlib)
"""
import csv
import hashlib
import json
import os
import sys
from pathlib import Path

os.environ.setdefault("SOURCE_DATE_EPOCH", "1728500000")

import numpy as np                     # noqa: E402
import matplotlib                      # noqa: E402
matplotlib.use("Agg")
import matplotlib.pyplot as plt        # noqa: E402
import matplotlib.patheffects as pe    # noqa: E402
from matplotlib.gridspec import GridSpec          # noqa: E402
from matplotlib.lines import Line2D               # noqa: E402
from matplotlib.patches import Patch              # noqa: E402

BASE = Path(__file__).resolve().parent
CSV_PATH = BASE / "Fig6_442_frozen_data.csv"

# ---------------- palette / typography (IEEE-print oriented) ----------
INK = "#28333B"
GRID = "#D9DEE3"
C_B1 = "#35618E"        # B1 bars (blue, fixed everywhere)
C_B3 = "#8C8C8C"        # B3 bars (neutral gray, "no grant")
C_PG = "#0F6E6E"        # PG identity: hollow zero markers + Installed
C_PG_LIGHT = "#7FB3AF"  # (c) canonical-hit series
C_OOR = "#D8974F"       # (b) Out-of-root segment
C_CAP = "#6B5B8A"       # (b) CAP_SCOPE segment
C_MALF = "#C9CFD4"      # (b) Malformed segment
C_LINE = "#37474F"      # (b) proposal-count line (distinct from stack)

F_PANEL, F_DOMAIN, F_TICK, F_LABEL = 8.4, 7.4, 6.4, 6.2
F_COUNT, F_LEGEND, F_NOTE = 6.3, 6.4, 6.2
LABEL_MIN_A = 4.0       # (a) bar label threshold (%)
SEG_MIN_B = 10.0        # (b) in-segment label threshold (%)

MODELS = ["GPT", "Claude", "GLM", "Gemini", "DeepSeek"]
SHORT = {"GPT": "GPT", "Claude": "Cla.", "GLM": "GLM",
         "Gemini": "Gem.", "DeepSeek": "DS"}
DOMAINS = ["CloudOps", "Procurement", "Finance", "Data Access"]
A_YLIM = {"CloudOps": 10, "Procurement": 60, "Finance": 100, "Data Access": 20}
A_YTICKS = {"CloudOps": (0, 5, 10), "Procurement": (0, 20, 40, 60),
            "Finance": (0, 25, 50, 75, 100), "Data Access": (0, 10, 20)}
STACK = ["Installed", "Out-of-root", "CAP_SCOPE", "Malformed"]
STACK_C = {"Installed": C_PG, "Out-of-root": C_OOR,
           "CAP_SCOPE": C_CAP, "Malformed": C_MALF}
STACK_TXT = {"Installed": "white", "Out-of-root": INK,
             "CAP_SCOPE": "white", "Malformed": INK}
N_HIST = 4000

plt.rcParams.update({
    "font.family": "DejaVu Sans", "pdf.fonttype": 42, "svg.fonttype": "none",
    "svg.hashsalt": "fig6v5",
    "text.color": INK, "axes.labelcolor": INK,
    "xtick.color": INK, "ytick.color": INK, "axes.edgecolor": INK,
    "axes.linewidth": 0.7, "grid.color": GRID, "grid.linewidth": 0.5,
    "xtick.major.width": 0.7, "ytick.major.width": 0.7,
    "xtick.major.size": 2.0, "ytick.major.size": 2.0,
})


class DataError(Exception):
    pass


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def wilson_ci(k, n, z=1.96):
    """Nominal 95% Wilson interval, in percent (asymmetric)."""
    if n == 0:
        return 0.0, 0.0
    p = k / n
    denom = 1 + z ** 2 / n
    center = (p + z ** 2 / (2 * n)) / denom
    half = z * np.sqrt(p * (1 - p) / n + z ** 2 / (4 * n ** 2)) / denom
    return (max(0.0, center - half) * 100, min(1.0, center + half) * 100)


def fmt_pct(x):
    r = round(x, 1)
    return f"{r:.0f}%" if abs(r - round(r)) < 0.051 else f"{r:.1f}%"
    # integers print bare; halves keep one decimal (4%, 7.5%, 13.5%, 91%)


def load_data():
    rows = list(csv.DictReader(open(CSV_PATH, encoding="utf-8-sig")))
    if len(rows) != 60:
        raise DataError(f"CSV rows {len(rows)} != 60")
    cells = {}
    for r in rows:
        key = (r["model"], r["domain"], r["method"])
        if key in cells:
            raise DataError(f"duplicate cell {key}")
        cells[key] = {k: int(v) for k, v in r.items()
                      if k not in ("model", "domain", "method")}
    want = {(m, d, meth) for m in MODELS for d in DOMAINS
            for meth in ("B1", "B3", "PG")}
    if set(cells) != want:
        raise DataError("model-domain-method grid incomplete")
    for (m, d, meth), c in cells.items():
        if c["N"] != 200:
            raise DataError(f"N != 200 at {(m, d, meth)}")
        if meth == "PG" and sum(c[s] for s in STACK) != c["proposed"]:
            raise DataError(f"PG dispositions != proposed at {(m, d)}")
        if c["installed"] != c["Installed"] and meth == "PG":
            raise DataError(f"installed != Installed at {(m, d)}")
    # headline guards (frozen experiment counts)
    tot = {}
    for meth in ("B1", "B3", "PG"):
        sel = [c for (m, d, mm), c in cells.items() if mm == meth]
        tot[meth] = {f: sum(c[f] for c in sel)
                     for f in ("cppe_issuer", "cppe_scope", "unauth_effect",
                               "proposed", "installed", "valid_accepted")}
    expect = {
        ("B1", "cppe_issuer"): 2960, ("B1", "cppe_scope"): 598,
        ("B1", "unauth_effect"): 584,
        ("B3", "cppe_issuer"): 2362, ("B3", "cppe_scope"): 0,
        ("B3", "unauth_effect"): 0,
        ("PG", "unauth_effect"): 0, ("PG", "proposed"): 3168,
        ("PG", "installed"): 2275, ("PG", "valid_accepted"): 720,
    }
    for (meth, f), v in expect.items():
        if tot[meth][f] != v:
            raise DataError(f"{meth}/{f}: {tot[meth][f]} != {v}")
    return cells, tot


def style(ax, yticks=None):
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y")
    ax.set_axisbelow(True)
    ax.tick_params(labelsize=F_TICK, pad=1.4)
    if yticks is not None:
        ax.set_yticks(yticks)


def halo(color, lw=1.4):
    return [pe.withStroke(linewidth=lw, foreground=color)]


def draw_rate_label(ax, x, rate, lo, hi, top, color_bar):
    """Label above CI if it fits, else inside the bar top (white)."""
    if hi + 0.03 * top <= top - 0.075 * top:
        ax.text(x, hi + 0.018 * top, fmt_pct(rate), ha="center", va="bottom",
                fontsize=F_LABEL, color=INK, zorder=6)
    else:
        ax.text(x, rate - 0.045 * top, fmt_pct(rate), ha="center", va="top",
                fontsize=F_LABEL + 0.2, color="white", fontweight="bold",
                zorder=6)


def zero_marker(ax, x, y=0.0, color=C_PG, ms=3.6):
    ax.plot([x], [y], marker="o", markersize=ms, markerfacecolor="white",
            markeredgecolor=color, markeredgewidth=1.0, linestyle="none",
            clip_on=False, zorder=5)


def panel_a(fig, gs, cells):
    axs = []
    for j, dom in enumerate(DOMAINS):
        ax = fig.add_subplot(gs[0, j])
        axs.append(ax)
        style(ax, A_YTICKS[dom])
        top = A_YLIM[dom]
        ax.set_ylim(0, top)
        ax.set_title(f"{dom} (0–{top}%)", fontsize=F_DOMAIN,
                     fontweight="bold", pad=2.6)
        ax.set_xlim(-0.55, 4.45)
        ax.set_xticks(range(5))
        ax.set_xticklabels([SHORT[m] for m in MODELS])
        ax.tick_params(axis="x", pad=1.2)
        for i, m in enumerate(MODELS):
            c = cells[(m, dom, "B1")]
            k, n = c["unauth_effect"], c["N"]
            rate = k / n * 100
            lo, hi = wilson_ci(k, n)
            if k > 0:
                ax.bar([i], [rate], width=0.60, color=C_B1,
                       edgecolor=C_B1, linewidth=0.4, zorder=3)
                ax.errorbar([i], [rate], yerr=[[rate - lo], [hi - rate]],
                            color=INK, linewidth=0.8, capsize=2.0,
                            capthick=0.8, zorder=4)
                if rate >= LABEL_MIN_A:
                    draw_rate_label(ax, i, rate, lo, hi, top, C_B1)
            zero_marker(ax, i)          # PG: 0/200 in every cell
        if j == 0:
            ax.set_ylabel("B1 effect rate (%)", fontsize=F_TICK + 0.6)
    return axs


def panel_b(fig, gs, cells):
    axs = []
    for j, dom in enumerate(DOMAINS):
        ax = fig.add_subplot(gs[1, j])
        axs.append(ax)
        style(ax, (0, 50, 100))
        ax.set_ylim(0, 112)
        ax.set_title(dom, fontsize=F_DOMAIN, fontweight="bold", pad=2.6)
        ax.set_xlim(-0.55, 4.45)
        ax.set_xticks(range(5))
        ax.set_xticklabels([SHORT[m] for m in MODELS])
        ax.tick_params(axis="x", pad=1.2)
        proposed = np.array(
            [cells[(m, dom, "PG")]["proposed"] for m in MODELS], float)
        bottom = np.zeros(5)
        for seg in STACK:
            share = np.array(
                [cells[(m, dom, "PG")][seg] for m in MODELS]) / proposed * 100
            ax.bar(range(5), share, bottom=bottom, width=0.60,
                   color=STACK_C[seg], edgecolor="white", linewidth=0.5,
                   zorder=3)
            for i, (s, b) in enumerate(zip(share, bottom)):
                if s >= SEG_MIN_B:
                    y = b + (0.40 if seg == STACK[-1] else 0.5) * s
                    ax.text(i, y, f"{round(s):.0f}%", ha="center",
                            va="center", fontsize=F_LABEL,
                            color=STACK_TXT[seg],
                            fontweight="bold" if seg == "Installed" else
                            "normal", zorder=6,
                            path_effects=halo(STACK_C[seg], 2.0))
            bottom += share
        if j == 0:
            ax.set_ylabel("Share of PG proposals (%)", fontsize=F_TICK + 0.6)
        # unified, directly comparable secondary axis (proposal counts)
        ax2 = ax.twinx()
        ax2.plot(range(5), proposed, color=C_LINE, linewidth=1.1,
                 marker="o", markersize=3.3, markerfacecolor=C_LINE,
                 markeredgecolor="white", markeredgewidth=0.5,
                 clip_on=False, zorder=4)
        ax2.set_ylim(0, 210)
        ax2.set_yticks([0, 50, 100, 150, 200])
        ax2.tick_params(labelsize=F_TICK - 0.4, colors=C_LINE, pad=1.2,
                        length=2.0, width=0.7)
        ax2.spines[["top", "left"]].set_visible(False)
        ax2.spines["right"].set_color(C_LINE)
        ax2.spines["right"].set_linewidth(0.7)
        if j == 3:
            ax2.set_ylabel("PG proposal count", fontsize=F_TICK + 0.6,
                           color=C_LINE)
    return axs


def panel_c(ax, cells):
    style(ax, (0, 25, 50, 75, 100))
    agg = {m: {f: sum(cells[(m, d, "PG")][f] for d in DOMAINS)
               for f in ("proposed", "installed", "valid_accepted")}
           for m in MODELS}
    ax.set_ylim(0, 108)
    ax.set_xlim(-0.55, 4.45)
    ax.set_xticks(range(5))
    ax.set_xticklabels(MODELS)
    ax.set_ylabel("Share of proposals (%)", fontsize=F_TICK + 0.6)
    for i, m in enumerate(MODELS):
        a = agg[m]
        for off, f, col in ((-0.19, "installed", C_PG),
                            (0.19, "valid_accepted", C_PG_LIGHT)):
            k, n = a[f], a["proposed"]
            rate = k / n * 100
            lo, hi = wilson_ci(k, n)
            if k > 0:
                ax.bar([i + off], [rate], width=0.34, color=col,
                       edgecolor=col, linewidth=0.4, zorder=3)
                ax.errorbar([i + off], [rate],
                            yerr=[[rate - lo], [hi - rate]], color=INK,
                            linewidth=0.8, capsize=2.0, capthick=0.8,
                            zorder=4)
                draw_rate_label(ax, i + off, rate, lo, hi, 108, col)
            else:
                zero_marker(ax, i + off)
    return [Patch(facecolor=C_PG, label="Installed / proposed"),
            Patch(facecolor=C_PG_LIGHT, label="Canonical hit / proposed")]


def panel_d(ax, tot):
    style(ax, (0, 20, 40, 60, 80))
    cats = ["Issuer-unsafe\ninstallation", "Scope-escaping\ninstallation",
            "Unauthorized\nsandbox effect"]
    ax.set_ylim(0, 82)
    ax.set_xlim(-0.55, 2.55)
    ax.set_xticks(range(3))
    ax.set_xticklabels(cats, fontsize=F_TICK)
    ax.set_ylabel("Histories (%)", fontsize=F_TICK + 0.6)
    series = [("B1", C_B1, -0.26), ("B3", C_B3, 0.0), ("PG", C_PG, 0.26)]
    for gi, field in enumerate(("cppe_issuer", "cppe_scope",
                                "unauth_effect")):
        for name, col, off in series:
            k = tot[name][field]
            x = gi + off
            if k > 0:
                rate = k / N_HIST * 100
                lo, hi = wilson_ci(k, N_HIST)
                ax.bar([x], [rate], width=0.23, color=col, edgecolor=col,
                       linewidth=0.4, zorder=3)
                ax.errorbar([x], [rate], yerr=[[rate - lo], [hi - rate]],
                            color=INK, linewidth=0.8, capsize=2.0,
                            capthick=0.8, zorder=4)
                ax.text(x, hi + 1.2, f"{k}", ha="center", va="bottom",
                        fontsize=F_COUNT, color=INK, zorder=6)
            else:
                zero_marker(ax, x, color=col)   # B3 zeros gray, PG teal
    return [Patch(facecolor=C_B1, label="B1"),
            Patch(facecolor=C_B3, label="B3 (no grant)"),
            Line2D([], [], marker="o", markersize=3.6,
                   markerfacecolor="white", markeredgecolor=C_PG,
                   markeredgewidth=1.0, linestyle="none",
                   label="PG: 0 in all layers")]


def draw(cells, tot):
    fig = plt.figure(figsize=(7.087, 6.5))
    gs = GridSpec(3, 4, figure=fig, height_ratios=[1.0, 1.0, 1.12],
                  left=0.074, right=0.973, top=0.972, bottom=0.052,
                  hspace=0.62, wspace=0.44)
    axs_a = panel_a(fig, gs, cells)
    axs_b = panel_b(fig, gs, cells)

    ax_c = fig.add_subplot(gs[2, 0:2])
    h_c = panel_c(ax_c, cells)
    ax_d = fig.add_subplot(gs[2, 2:4])
    h_d = panel_d(ax_d, tot)

    def band_title(ax, text):
        ax.set_title(text, loc="left", fontsize=F_PANEL, fontweight="bold",
                     pad=30)

    band_title(ax_c, "(c) Conditional PG installation and reuse")
    band_title(ax_d, "(d) Failures across enforcement layers")
    for ax, handles, ncol in ((ax_c, h_c, 2), (ax_d, h_d, 3)):
        ax.legend(handles=handles, loc="lower left", bbox_to_anchor=(0.0, 1.035),
                  ncol=ncol, frameon=False, fontsize=F_LEGEND,
                  handlelength=1.1, handleheight=0.85, columnspacing=1.0,
                  borderaxespad=0.0, handletextpad=0.45)

    # row bands: title left, legend right, small note under it
    ya = axs_a[0].get_position().y1
    fig.text(0.074, ya + 0.030, "(a) Unauthorized sandbox-probe effects",
             fontsize=F_PANEL, fontweight="bold", va="bottom")
    fig.legend(handles=[Patch(facecolor=C_B1, label="B1 effect rate"),
                        Line2D([], [], marker="o", markersize=3.6,
                               markerfacecolor="white",
                               markeredgecolor=C_PG, markeredgewidth=1.0,
                               linestyle="none",
                               label="PG: 0/200 in every cell")],
               loc="upper right", bbox_to_anchor=(0.973, ya + 0.052), ncol=2,
               frameon=False, fontsize=F_LEGEND, handlelength=1.1,
               handletextpad=0.45, columnspacing=0.9, borderaxespad=0.0)
    fig.text(0.973, ya + 0.014, "n = 200 per model×domain cell · "
             "nominal 95% Wilson intervals", fontsize=F_NOTE, ha="right",
             va="bottom", color="#5A646B")

    yb = axs_b[0].get_position().y1
    fig.text(0.074, yb + 0.030, "(b) PG proposal dispositions by domain",
             fontsize=F_PANEL, fontweight="bold", va="bottom")
    fig.legend(handles=[Patch(facecolor=STACK_C[s], label=s) for s in STACK]
               + [Line2D([], [], marker="o", markersize=3.3,
                         markerfacecolor=C_LINE, markeredgecolor="white",
                         markeredgewidth=0.5, linestyle="none",
                         linewidth=1.1, color=C_LINE,
                         label="Proposal count (right axis)")],
               loc="upper right", bbox_to_anchor=(0.973, yb + 0.052), ncol=5,
               frameon=False, fontsize=F_LEGEND, handlelength=1.1,
               handleheight=0.85, columnspacing=0.9, borderaxespad=0.0,
               handletextpad=0.45)
    fig.text(0.973, yb + 0.014,
             "bars: disposition shares of that cell’s PG proposals",
             fontsize=F_NOTE, ha="right", va="bottom", color="#5A646B")
    return fig


def main():
    cells, tot = load_data()
    fig = draw(cells, tot)
    fig.savefig(BASE / "Fig6_442_final_polish_v5.pdf")
    fig.savefig(BASE / "Fig6_442_final_polish_v5.png", dpi=300)
    fig.savefig(BASE / "Fig6_442_final_polish_v5.svg")
    plt.close(fig)

    # data + config audit
    b3p = tot["B3"]["cppe_issuer"] / N_HIST * 100
    audit = {
        "figure_id": "Fig6_442_final_polish_v5",
        "base_layout": "Fig6_442 (4+4+2), polish pass only",
        "csv_sha256": sha256(CSV_PATH),
        "csv_expected_sha256": ("fc780a7c5160d5281350fa19898195"
                                "acd6bcf03232a651e43ee9cac5d4b8d54d"),
        "data_checks": {
            "rows": 60, "grid_complete": "5 models x 4 domains x 3 methods",
            "N_per_cell": 200,
            "pg_disposition_sums_equal_proposed": True,
            "B1_issuer_unsafe_per_4000": 2960,
            "B1_scope_escaping_per_4000": 598,
            "B1_unauthorized_effects_per_4000": 584,
            "B3_issuer_unsafe_per_4000": 2362,
            "B3_scope_escaping_per_4000": 0,
            "B3_unauthorized_effects_per_4000": 0,
            "PG_unauthorized_effects_per_4000": 0,
            "PG_proposed": 3168, "PG_installed": 2275, "PG_canonical": 720,
            "panel_a_metric": "B1 unauth_effect / 200 per cell",
            "panel_b_metric": "PG disposition / PG proposed per cell; "
                              "line = raw PG proposed count",
            "panel_c_metric": "model-summed counts / model proposals "
                              "(no averaging of domain percentages)",
            "panel_d_denominator": 4000,
            "wilson": "nominal 95%, asymmetric, z=1.96",
            "b3_rate_pct_check": round(b3p, 2),
        },
        "config": {
            "figsize_in": [7.087, 6.5], "display_width_check": "7.0 in "
            "(IEEEtran conference,compsoc figure* \\textwidth)",
            "panel_a_label_threshold_pct": LABEL_MIN_A,
            "panel_b_segment_label_threshold_pct": SEG_MIN_B,
            "panel_a_ylims": A_YLIM,
            "panel_b_right_axis_ylim": [0, 210],
            "panel_b_right_axis_unified": True,
            "panel_c_ylim": 108, "panel_d_ylim": 82,
            "fonts_pt": {"panel": F_PANEL, "domain": F_DOMAIN,
                         "ticks": F_TICK, "labels": F_LABEL,
                         "legend": F_LEGEND, "note": F_NOTE},
            "colors": {"B1": C_B1, "B3": C_B3, "PG": C_PG,
                       "PG_light": C_PG_LIGHT, "Installed": C_PG,
                       "Out-of-root": C_OOR, "CAP_SCOPE": C_CAP,
                       "Malformed": C_MALF, "line": C_LINE},
            "zero_marker": "hollow circle, white face, series edge color",
            "font": "DejaVu Sans, pdf.fonttype=42 (embedded TrueType), "
                    "svg.fonttype=none (editable text)",
            "determinism": {"SOURCE_DATE_EPOCH": os.environ[
                "SOURCE_DATE_EPOCH"]},
        },
        "outputs": {
            n: sha256(BASE / f"Fig6_442_final_polish_v5.{e}")
            for n, e in (("png", "png"), ("pdf", "pdf"), ("svg", "svg"))},
        "matplotlib": matplotlib.__version__, "numpy": np.__version__,
        "python": sys.version.split()[0],
    }
    if audit["csv_sha256"] != audit["csv_expected_sha256"]:
        raise DataError("frozen CSV hash changed")
    (BASE / "Fig6_442_final_audit.json").write_text(
        json.dumps(audit, indent=1), encoding="utf-8")
    print("guards PASS; rendered png/pdf/svg + audit")


if __name__ == "__main__":
    main()
