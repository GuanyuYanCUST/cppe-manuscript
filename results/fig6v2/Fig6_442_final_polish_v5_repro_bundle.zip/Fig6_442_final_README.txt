Fig6_442_final_polish_v5 — final visual polish of the approved Fig.6
====================================================================

Base: the user-approved Fig6_442 layout (4 + 4 + 2 panels). Frozen CSV
byte-identical to Fig6_442_frozen_data.csv (sha256 fc780a7c...d54d,
recorded in Fig6_442_final_audit.json). No count, ratio, denominator,
model order, or domain order was changed; the script refuses to render
unless every frozen headline count re-derives from the CSV.

Files
-----
- Fig6_442_final_polish_v5.png   300 dpi raster preview
- Fig6_442_final_polish_v5.pdf   vector PDF, DejaVu Sans embedded
                                 (TrueType subsets, pdf.fonttype=42)
- Fig6_442_final_polish_v5.svg   vector SVG, editable <text> kept
                                 (svg.fonttype='none', 162 text nodes)
- Fig6_442_final_polish_v5.py    standalone reproduction script
                                 (stdlib csv + numpy + matplotlib only;
                                 no pandas dependency)
- Fig6_442_frozen_data.csv       byte-identical copy of the frozen CSV
- Fig6_442_final_IEEE_caption.tex  full-restriction IEEE caption
- Fig6_442_final_audit.json      data guards, config, output hashes
- Fig6_442_final_README.txt      this file

Reproduce (any platform)
------------------------
Windows (py launcher):   py -3.11 Fig6_442_final_polish_v5.py
Linux/WSL:               python3 Fig6_442_final_polish_v5.py
Dependencies: numpy, matplotlib (tested numpy 2.2.6 / matplotlib
3.10.9 / Python 3.11). Run from this directory. SOURCE_DATE_EPOCH is
pinned and svg.hashsalt is fixed, so re-runs are byte-identical
(verified: two independent runs -> identical PNG, PDF, SVG sha256).

IEEE usage
----------
Include in a spanning environment at true column width:
  \begin{figure*}[t]
    \centering
    \includegraphics[width=\textwidth]{Fig6_442_final_polish_v5.pdf}
    % caption: see Fig6_442_final_IEEE_caption.tex
  \end{figure*}
Figure is authored at 7.087 x 6.5 in, matching IEEEtran
conference,compsoc \textwidth; verified in a two-page IEEEtran probe
compile (0 Overfull warnings) and inspected at final print size.

Visual changes vs the approved Fig6_442 (v4) render
---------------------------------------------------
Panel (a)
- Rate labels only for B1 >= 4% (was: every nonzero bar); compact
  format, integers without decimals (4%, 6%, 7.5%, 13.5%, 52%, 91%).
- Labels that would clash with the Wilson upper bound are placed
  inside the bar top in white instead of above it; no bar height or
  interval was altered.
- PG zero markers kept as full hollow circles (never half-clipped).
- Per-domain y ranges kept and printed in each domain title
  (CloudOps 0-10%, Procurement 0-60%, Finance 0-100%, Data Access
  0-20%); moved the "k=.../200" wording out of the plot.
Panel (b)
- Proposal-count line: thinner (1.1 pt), smaller markers, dark
  slate #37474F distinct from all four stack colors.
- Right axes of all four domains now share one 0-200 scale with
  headroom, so counts are directly comparable; markers never clip.
- In-segment labels only for shares >= 10%; top-segment labels sit at
  40% segment height with a wider same-color halo so the count line
  can never obscure them; Installed keeps bold white text.
- Shared 5-entry legend (4 dispositions + proposal count) in the row
  band; no per-bar P= footnotes under the x axis.
Panel (c)
- Full model names; PG teal identity colors (dark = installed share,
  light = canonical-hit share) matching (b)/(d); Wilson intervals in
  the same ink style as (a)/(d).
- Claude's canonical hit = 0 shown as a hollow marker at zero, not a
  fake bar or floating number.
Panel (d)
- Fixed series colors: B1 steel blue, B3 neutral gray labeled
  "B3 (no grant)", PG hollow teal circles identical in color/shape to
  panel (a) markers; legend matches the plot exactly.
- Raw counts (2960, 2362, 598, 584) above bars; zeros drawn only as
  open markers (no redundant "0" text that could read as an event).
Typography/layout
- Unified hierarchy: panel titles 8.4 pt bold, domain titles 7.4 pt,
  ticks 6.4 pt, data labels 6.2-6.4 pt, legend 6.4 pt (was: 10-17.5 pt
  on a 12.3-in canvas, i.e. ~6-9 pt after scaling, with heavy bold).
- Canvas is authored at final print width (7.087 in), so the type
  sizes above are the true printed sizes; grid lightened to 0.5 pt
  horizontal-only; long in-figure explanations moved to the caption
  (only two short axis-explaining notes remain).
- Rows align through one 4-column grid; row (c)/(d) split 2+2.

QA performed
------------
1. Script runs clean; all data guards PASS (60 rows; 5x4x3 grid
   complete; PG dispositions sum to proposed per cell; B1 2960/598/584,
   B3 2362/0/0, PG 0/3168/2275/720 per 4,000-2).
2. PNG inspected full-size plus native-resolution crops of every row.
3. Panel (a) and (b) inspected at 300-400 dpi at IEEE print size
   (labels, intervals, line markers, secondary axes all resolved).
4. IEEEtran conference probe at \textwidth: 0 Overfull, figure on its
   own page region, grayscale render still separates all series.
5. PDF: embedded TrueType subsets, 538 vector objects, text layer
   intact for all (a)/(c)/(d) labels; (b) in-bar labels are stroked
   paths (halo) by design.
6. SVG: 162 editable <text> nodes, vector throughout.
7. Two independent runs: PNG/PDF/SVG byte-identical (hashes in audit).

Known residual limitations
--------------------------
- In grayscale, panel (b) Installed vs CAP_SCOPE are both dark
  (separated by white rules, fixed stacking order, and labels); the
  camera-ready figure is color.
- Panel (b) in-bar labels are rendered as stroked paths in the PDF
  (halo against the count line); all other text is real, embedded text.
